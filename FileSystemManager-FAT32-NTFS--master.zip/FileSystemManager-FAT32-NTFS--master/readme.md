﻿**I.  MINH HỌA CHƯƠNG TRÌNH** 

Có 2 cách để chạy chương trình 

`  `+Có thể mở visual studio để chạy code 

`  `+Chạy file SystemFile.exe trong thư mục Release 

Lưu ý: Phải chạy chương trình bằng quyền quản trị (Run as administrator) 

1. **FAT32** 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.001.png)

Chọn ổ đĩa E:/ có File System là FAT32 để kiểm thử. 

**B1:** Sau khi mở chương trình lên giao diện sẽ hiển thị như hình dưới. Nhập tên ổ đĩa cầm xem (nhập E để demo) 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.002.png)

Giao diện bảng chọn được hiện thị sau khi chọn ổ đĩa: 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.003.jpeg)

*Nếu bạn muốn thay đổi volume khác có thể nhập số 1.* 

**B2:** Nhập 2 để xem thông tin Boot secter, sau đó nhấn phím bất kỳ để trở lại menu 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.004.jpeg)

**B3** :Nhập 3 để xem cây thư mục.**  

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.005.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.006.jpeg)

`                               `**1  2** 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.007.jpeg)

**3** 

**B4** :Nhập 4 để xem chi tiết cây thư mục.**  

*Hình dưới mô tả một phần hiển thị cây thư mục chi tiết.* 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.008.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.009.jpeg)

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.010.jpeg)

**B5 :**Nhập 5 để tìm file hoặc Folder 

+ Tìm file: 19120628.txt 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.011.jpeg)

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.012.jpeg)

Phần  nội dung để đối chiếu ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.013.jpeg)![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.014.png)

+ Tìm Folder: Mo ta CSDL     (E:/CSDL/Mo ta CSDL) 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.015.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.016.jpeg)

1  2 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.017.jpeg)

3 

2. **NTFS** 

Chọn ổ đĩa F:/ có File System là NTFS để kiểm thử. 

` `![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.018.png) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.019.png)![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.020.png)

**B1:** Sau khi mở chương trình lên giao diện sẽ hiển thị như hình dưới. Nhập tên ổ đĩa cần xem (nhập F để demo) 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.021.jpeg)

Giao diện bảng chọn được hiện thị sau khi chọn ổ đĩa: 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.022.jpeg)

**B2:** Nhập 2 để xem thông tin Patition Boot secter, sau đó nhấn phím bất kỳ để trở lại menu 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.023.jpeg)

**B3:** Nhập 3 để xem cây thư mục. 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.024.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.025.jpeg)

1       2 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.026.jpeg)

3 

**B4**: Nhập 4 để xem cây thư mục chi tiết 

Một phần của cây thư mục chi tiết 

` `![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.027.jpeg)![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.028.jpeg)

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.029.jpeg)

**B5 :**Nhập 5 để tìm file hoặc Folder 

+ Tìm file: Quanlychuyenbay.txt 

Một phần của nội dung do file có kích thước lớn(28302byte) 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.030.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.031.jpeg)

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.032.jpeg)

+ Tìm Folder: CSDL  (E:/CSDL) 

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.033.jpeg) ![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.034.jpeg)

![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.035.jpeg)
` `13![](markdown-image/Aspose.Words.32f68f9b-fe5e-485c-9999-7e515ff89d54.036.png)

